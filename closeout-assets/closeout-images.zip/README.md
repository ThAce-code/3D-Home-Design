# V4–V6 MVP 结项

范围依据 `docs/plans/2026-11-04-remaining-version-completion-plan.md`。
当前完成专业墙体编辑、撤销重做、门窗占位模型及属性、房间面积标签、PNG 导出、日夜图片切换。
本次补齐统一编辑器中的家具库入口、家具属性操作、建筑/家具选中切换，以及同时保存建筑与家具。

## 交付图

六张 1920×1080 PNG 均由 Playwright 对实际运行的应用直接截图，未合成界面或叠加宣传图形。
1. `01-room-building.png`：7×5 米示例房间，墙高设置为 2.8 米；展示墙高调节，并非矩形拖拽工具。
2. `02-wall-editing.png`：俯视选中墙体、端点及长度标签，厚度调整为 0.24 米。
3. `03-furniture-layout.png`：实际上传的沙发、茶几 GLB，家具旋转控件和位置/缩放属性。
4. `04-interior-export.png`：室内视角与 PNG 导出成功界面。
5. `05-landing-day-en.png`：英文落地页白天模式。
6. `06-landing-night-en.png`：英文落地页夜晚模式，使用实际夜景背景图片。
另附 `scene-export.png`，为软件导出的纯画布图片。

示例房间通过应用现有绘墙命令建立；家具为原创简化演示模型，经真实上传 API 入库和缩略图生成。示例数据不是用户的实际设计项目。

## 重拍

启动前后端及 PostgreSQL，安装 Chromium 后，在仓库根目录运行：

```bash
CLOSEOUT_DIR=/workspace/closeout node scripts/capture-closeout.cjs
CLOSEOUT_DIR=/workspace/closeout node scripts/capture-landing-closeout.cjs
```

脚本使用独立浏览器会话，依次操作真实的墙体数值、GLB 上传、家具工具和 PNG 导出，并验证保存后恢复房间及家具。已存在的同名示例资源会复用。

## 边界

门窗按 V5 MVP 提供占位几何，尚非墙体布尔开洞。PNG 为当前 WebGL 画布截图，HTML 面积标签不包含在纯画布导出内。多人协作、素材商城、户型图导入、多楼层/楼梯及在线分享属于原计划明确排除的 V7+，不在本次结项范围。

## 验收结果

- `npm run lint`、`npm run build`：通过。
- `npm run test:unit -- --run`：60 文件、308 用例通过。
- professional-editing、pointer-lock、fly-indicator、review-regressions：24 个浏览器用例通过；一次页面重新加载干扰的房间删除用例单独重跑通过。
- 最终拍摄脚本：4 张运行截图、PNG 导出完成；保存后刷新确认恢复 4 面墙和 2 件家具。
- 当前修改位于工作区，尚未提交或推送；未发布生产版本。
